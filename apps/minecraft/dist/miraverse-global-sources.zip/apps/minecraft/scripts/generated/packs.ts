// GENERATED FILE - DO NOT EDIT
import type { Pack } from '../../../../packages/content/schema.js';

export const PACKS: Pack[] = [
  {
    "chapters": [
      {
        "challenges": [
          {
            "goal_en": "Collect rice, brown lentils, and spiced tomato sauce from the market stalls for Teta Samira's koshari pot.",
            "id": "EG-1-gather",
            "needs": [
              {
                "count": 2,
                "item": "rice"
              },
              {
                "count": 2,
                "item": "lentils"
              },
              {
                "count": 1,
                "item": "tomato_sauce"
              }
            ],
            "title_en": "Pantry on the Corniche",
            "type": "gather"
          },
          {
            "goal_en": "Layer the rice, lentils, spiced tomato sauce, and golden crispy onions in order to prepare a festive bowl of Egyptian koshari.",
            "id": "EG-1-cook",
            "recipe": {
              "inputs": [
                "rice",
                "lentils",
                "tomato_sauce",
                "crispy_onions"
              ],
              "output": "koshari"
            },
            "title_en": "Teta Samira's Koshari",
            "type": "cook"
          },
          {
            "blueprint": [
              "..S..",
              ".SSS.",
              "..S..",
              "PPPPP"
            ],
            "blueprintLegend": {
              "P": "acacia_plank",
              "S": "linen_sail"
            },
            "goal_en": "Assemble a traditional wooden Nile felucca hull with acacia planks and hoist its tall white linen sail.",
            "id": "EG-1-build",
            "title_en": "Felucca on the Nile",
            "type": "build"
          },
          {
            "goal_en": "Share a warm bowl of homemade koshari with the bazaar artisan in exchange for a brass fanous lantern.",
            "id": "EG-1-trade",
            "needs": [
              {
                "count": 1,
                "item": "koshari"
              }
            ],
            "reward": {
              "count": 1,
              "item": "fanous_lantern"
            },
            "title_en": "Lanterns of Khan el-Khalili",
            "type": "trade"
          },
          {
            "goal_en": "Practice three everyday Cairene Egyptian Arabic words with Teta Samira before the evening river boat sets sail.",
            "id": "EG-1-word",
            "title_en": "Words from Cairo",
            "type": "word",
            "words": [
              {
                "en": "Egyptian dish of rice, lentils, spiced tomato sauce, and crispy onions",
                "translit": "koshari",
                "word": "كشري"
              },
              {
                "en": "traditional decorative lantern",
                "translit": "fanous",
                "word": "فانوس"
              },
              {
                "en": "wooden sailboat on the Nile",
                "translit": "felucca",
                "word": "فلوكة"
              }
            ]
          }
        ],
        "id": 1,
        "title_en": "Lanterns on the Nile"
      }
    ],
    "colors": {
      "primary": "#1E5B88",
      "secondary": "#D99B26"
    },
    "country": "EG",
    "items": [
      {
        "color": "#8B5A2B",
        "id": "acacia_plank",
        "name_en": "Acacia Wood Plank"
      },
      {
        "color": "#B87333",
        "id": "crispy_onions",
        "name_en": "Golden Crispy Onions"
      },
      {
        "color": "#E5A93C",
        "id": "fanous_lantern",
        "name_en": "Brass Fanous Lantern"
      },
      {
        "color": "#A84A28",
        "id": "koshari",
        "name_en": "Bowl of Koshari"
      },
      {
        "color": "#5C4033",
        "id": "lentils",
        "name_en": "Brown Lentils"
      },
      {
        "color": "#FAF8F5",
        "id": "linen_sail",
        "name_en": "Woven Linen Sail"
      },
      {
        "color": "#F5F0E6",
        "id": "rice",
        "name_en": "Egyptian Short-Grain Rice"
      },
      {
        "color": "#C83E2B",
        "id": "tomato_sauce",
        "name_en": "Spiced Garlic Tomato Sauce"
      }
    ],
    "lang": "ar-EG",
    "mentor": {
      "greeting": "أهلاً وسهلاً يا حبيبي! نوّرت مصر، تعالَ نعمل أحلى طبق كشري ونعلّق فوانيس النيل سوا.",
      "greeting_en": "Welcome, my dear! You have lit up Egypt—come, let's make a warm bowl of koshari and hang the Nile lanterns together.",
      "name": "Teta Samira"
    },
    "name_en": "Egypt",
    "regions": [
      {
        "id": "cairo",
        "name_en": "Cairo"
      },
      {
        "id": "alexandria",
        "name_en": "Alexandria"
      },
      {
        "id": "aswan",
        "name_en": "Aswan"
      }
    ]
  },
  {
    "chapters": [
      {
        "challenges": [
          {
            "goal_en": "Gather flaky puff pastry, sweet almond cream, and a tiny porcelain fève charm for Mamie Claire.",
            "id": "FR-1-gather",
            "needs": [
              {
                "count": 2,
                "item": "puff_pastry"
              },
              {
                "count": 1,
                "item": "almond_cream"
              },
              {
                "count": 1,
                "item": "porcelain_feve"
              }
            ],
            "title_en": "Market Day at Les Halles",
            "type": "gather"
          },
          {
            "goal_en": "Layer the puff pastry with almond cream, tuck in the porcelain fève, and help Mamie Claire bake the golden galette.",
            "id": "FR-1-cook",
            "recipe": {
              "inputs": [
                "puff_pastry",
                "almond_cream",
                "porcelain_feve"
              ],
              "output": "galette_des_rois"
            },
            "title_en": "Baking the Galette des Rois",
            "type": "cook"
          },
          {
            "blueprint": [
              ".RRRR.",
              "RRRRRR",
              "SOSSOS",
              "SOSSOS",
              "SSSSSS"
            ],
            "blueprintLegend": {
              "O": "oak_shutter",
              "R": "slate_roof",
              "S": "cut_stone"
            },
            "goal_en": "Restore the neighborhood boulangerie facade with slate roof tiles, limestone walls, and oak shutters.",
            "id": "FR-1-build",
            "title_en": "The Vieux Lyon Bakery Facade",
            "type": "build"
          },
          {
            "goal_en": "Share a warm Galette des Rois with the neighborhood baker in exchange for a festive Golden Paper Crown.",
            "id": "FR-1-trade",
            "needs": [
              {
                "count": 1,
                "item": "galette_des_rois"
              }
            ],
            "reward": {
              "count": 1,
              "item": "paper_crown"
            },
            "title_en": "Sharing the Epiphany Treat",
            "type": "trade"
          },
          {
            "goal_en": "Learn three everyday French words from Mamie Claire's kitchen in Lyon.",
            "id": "FR-1-word",
            "title_en": "French Bakery Words",
            "type": "word",
            "words": [
              {
                "en": "flaky pastry cake",
                "translit": "la ga-let",
                "word": "la galette"
              },
              {
                "en": "hidden porcelain charm",
                "translit": "la fev",
                "word": "la fève"
              },
              {
                "en": "crown",
                "translit": "la koo-ron",
                "word": "la couronne"
              }
            ]
          }
        ],
        "id": 1,
        "title_en": "The Golden Galette of Lyon"
      }
    ],
    "colors": {
      "primary": "#1E3A8A",
      "secondary": "#E5A93B"
    },
    "country": "FR",
    "items": [
      {
        "color": "#FAE8C8",
        "id": "almond_cream",
        "name_en": "Sweet Almond Cream"
      },
      {
        "color": "#E2D9C8",
        "id": "cut_stone",
        "name_en": "Lyon Cut Limestone"
      },
      {
        "color": "#D99226",
        "id": "galette_des_rois",
        "name_en": "Galette des Rois"
      },
      {
        "color": "#854D0E",
        "id": "oak_shutter",
        "name_en": "Carved Oak Shutter"
      },
      {
        "color": "#FACC15",
        "id": "paper_crown",
        "name_en": "Golden Paper Crown"
      },
      {
        "color": "#E0F2FE",
        "id": "porcelain_feve",
        "name_en": "Porcelain Fève Charm"
      },
      {
        "color": "#F3D59B",
        "id": "puff_pastry",
        "name_en": "Flaky Puff Pastry"
      },
      {
        "color": "#475569",
        "id": "slate_roof",
        "name_en": "Mansard Slate Roof Tile"
      }
    ],
    "lang": "fr",
    "mentor": {
      "greeting": "Bienvenue dans ma cuisine à Lyon ! Préparons ensemble une belle galette des rois toute dorée.",
      "greeting_en": "Welcome to my kitchen in Lyon! Let us bake a warm golden galette des rois together.",
      "name": "Mamie Claire"
    },
    "name_en": "France",
    "regions": [
      {
        "id": "lyon",
        "name_en": "Lyon"
      },
      {
        "id": "paris",
        "name_en": "Paris"
      },
      {
        "id": "marseille",
        "name_en": "Marseille"
      }
    ]
  },
  {
    "chapters": [
      {
        "challenges": [
          {
            "goal_en": "Gather warm wheat dough, sweet date paste, and fragrant cardamom with Bibi Amal for the Eid baking tray.",
            "id": "IQ-1-gather",
            "needs": [
              {
                "count": 2,
                "item": "wheat_dough"
              },
              {
                "count": 2,
                "item": "date_paste"
              },
              {
                "count": 1,
                "item": "cardamom"
              }
            ],
            "title_en": "Pantry by the Tigris",
            "type": "gather"
          },
          {
            "goal_en": "Roll the spiced wheat dough around the date paste and cardamom filling so Bibi Amal can bake golden kleicha cookies.",
            "id": "IQ-1-cook",
            "recipe": {
              "inputs": [
                "wheat_dough",
                "date_paste",
                "cardamom"
              ],
              "output": "kleicha"
            },
            "title_en": "Bake the Eid Kleicha",
            "type": "cook"
          },
          {
            "blueprint": [
              "TTTTT",
              "BPPPB",
              "B...B",
              "BB.BB"
            ],
            "blueprintLegend": {
              "B": "mud_brick",
              "P": "palm_wood",
              "T": "turquoise_tile"
            },
            "goal_en": "Lay the mud-brick walls, palm-wood shanashil beams, and turquoise tiles around the family courtyard.",
            "id": "IQ-1-build",
            "title_en": "Baghdadi Courtyard House",
            "type": "build"
          },
          {
            "goal_en": "Share a plate of fresh Eid kleicha with the neighborhood coppersmith in exchange for a polished brass teapot.",
            "id": "IQ-1-trade",
            "needs": [
              {
                "count": 1,
                "item": "kleicha"
              }
            ],
            "reward": {
              "count": 1,
              "item": "brass_teapot"
            },
            "title_en": "Tea in Al-Mutanabbi",
            "type": "trade"
          },
          {
            "goal_en": "Learn three Baghdadi Iraqi Arabic words used during family Eid gatherings.",
            "id": "IQ-1-word",
            "title_en": "Words from Bibi's Courtyard",
            "type": "word",
            "words": [
              {
                "en": "spiced date-filled Eid cookie",
                "translit": "kleicha",
                "word": "كليچة"
              },
              {
                "en": "grandmother",
                "translit": "bibi",
                "word": "بيبي"
              },
              {
                "en": "what's up / how is everything",
                "translit": "shaku maku",
                "word": "شكو ماكو"
              }
            ]
          }
        ],
        "id": 1,
        "title_en": "Eid by the Tigris"
      }
    ],
    "colors": {
      "primary": "#1A7B88",
      "secondary": "#D4882A"
    },
    "country": "IQ",
    "items": [
      {
        "color": "#D4AF37",
        "id": "brass_teapot",
        "name_en": "Baghdadi Brass Teapot"
      },
      {
        "color": "#6E8B3D",
        "id": "cardamom",
        "name_en": "Ground Cardamom"
      },
      {
        "color": "#5C2C16",
        "id": "date_paste",
        "name_en": "Date Paste"
      },
      {
        "color": "#D49B4B",
        "id": "kleicha",
        "name_en": "Eid Kleicha"
      },
      {
        "color": "#C29B61",
        "id": "mud_brick",
        "name_en": "Tigris Mud Brick"
      },
      {
        "color": "#8B5A2B",
        "id": "palm_wood",
        "name_en": "Date Palm Beam"
      },
      {
        "color": "#1A8C9C",
        "id": "turquoise_tile",
        "name_en": "Turquoise Glazed Tile"
      },
      {
        "color": "#F3E5AB",
        "id": "wheat_dough",
        "name_en": "Wheat Dough"
      }
    ],
    "lang": "ar-IQ",
    "mentor": {
      "greeting": "هلا بيكم يا عيوني! تعالوا نخبز كليچة العيد ونشرب چاي مهيل بالحوش.",
      "greeting_en": "Welcome, my dears! Come bake Eid kleicha and drink cardamom tea in the courtyard.",
      "name": "Bibi Amal"
    },
    "name_en": "Iraq",
    "regions": [
      {
        "id": "baghdad",
        "name_en": "Baghdad"
      },
      {
        "id": "erbil",
        "name_en": "Erbil"
      },
      {
        "id": "basra",
        "name_en": "Basra"
      }
    ]
  },
  {
    "chapters": [
      {
        "challenges": [
          {
            "goal_en": "Gather freshly milled rice flour, sweet sesame-honey filling, and fragrant pine needles for the courtyard steamer.",
            "id": "KR-1-gather",
            "needs": [
              {
                "count": 2,
                "item": "rice_flour"
              },
              {
                "count": 2,
                "item": "sesame_honey"
              },
              {
                "count": 2,
                "item": "pine_needles"
              }
            ],
            "title_en": "Chuseok Basket in Jeonju",
            "type": "gather"
          },
          {
            "goal_en": "Knead the rice flour dough, fold in the sesame-honey filling, and layer over pine needles so Halmeoni can steam the songpyeon.",
            "id": "KR-1-cook",
            "recipe": {
              "inputs": [
                "rice_flour",
                "sesame_honey",
                "pine_needles"
              ],
              "output": "songpyeon"
            },
            "title_en": "Steam Half-Moon Songpyeon",
            "type": "cook"
          },
          {
            "blueprint": [
              "GGGG",
              "PHHP",
              "PHHP"
            ],
            "blueprintLegend": {
              "G": "giwa_tile",
              "H": "hanji_paper",
              "P": "pine_pillar"
            },
            "goal_en": "Arrange curved giwa roof tiles above sturdy pine pillars and warm hanji paper doors.",
            "id": "KR-1-build",
            "title_en": "Restore the Hanok Courtyard Pavilion",
            "type": "build"
          },
          {
            "goal_en": "Offer a plate of warm songpyeon to the neighborhood potter and receive an inlaid celadon tea cup in return.",
            "id": "KR-1-trade",
            "needs": [
              {
                "count": 1,
                "item": "songpyeon"
              }
            ],
            "reward": {
              "count": 1,
              "item": "celadon_cup"
            },
            "title_en": "Share Chuseok Songpyeon",
            "type": "trade"
          },
          {
            "goal_en": "Learn three Korean words for Chuseok traditions in Jeonju.",
            "id": "KR-1-word",
            "title_en": "Jeonju Harvest Words",
            "type": "word",
            "words": [
              {
                "en": "half-moon rice cake",
                "translit": "songpyeon",
                "word": "송편"
              },
              {
                "en": "traditional Korean house",
                "translit": "hanok",
                "word": "한옥"
              },
              {
                "en": "autumn harvest festival",
                "translit": "chuseok",
                "word": "추석"
              }
            ]
          }
        ],
        "id": 1,
        "title_en": "Harvest Moon in Jeonju"
      }
    ],
    "colors": {
      "primary": "#2E7D6F",
      "secondary": "#C84B31"
    },
    "country": "KR",
    "items": [
      {
        "color": "#7BA899",
        "id": "celadon_cup",
        "name_en": "Inlaid Celadon Tea Cup"
      },
      {
        "color": "#3B444B",
        "id": "giwa_tile",
        "name_en": "Curved Giwa Roof Tile"
      },
      {
        "color": "#F3EAD8",
        "id": "hanji_paper",
        "name_en": "Mulberry Hanji Screen"
      },
      {
        "color": "#3A6B4C",
        "id": "pine_needles",
        "name_en": "Fresh Pine Needles"
      },
      {
        "color": "#8C5332",
        "id": "pine_pillar",
        "name_en": "Red Pine Pillar"
      },
      {
        "color": "#F7F4EB",
        "id": "rice_flour",
        "name_en": "Rice Flour"
      },
      {
        "color": "#D49B35",
        "id": "sesame_honey",
        "name_en": "Sesame & Honey Filling"
      },
      {
        "color": "#E8A598",
        "id": "songpyeon",
        "name_en": "Half-Moon Songpyeon"
      }
    ],
    "lang": "ko",
    "mentor": {
      "greeting": "어서 오렴, 우리 손주! 전주 한옥 마루에서 밝은 보름달을 보며 따뜻한 송편을 함께 빚자꾸나.",
      "greeting_en": "Welcome, sweet grandchild! Let's shape warm songpyeon together under the bright harvest moon in Jeonju.",
      "name": "Halmeoni"
    },
    "name_en": "South Korea",
    "regions": [
      {
        "id": "seoul",
        "name_en": "Seoul"
      },
      {
        "id": "jeonju",
        "name_en": "Jeonju"
      },
      {
        "id": "busan",
        "name_en": "Busan"
      }
    ]
  },
  {
    "chapters": [
      {
        "challenges": [
          {
            "goal_en": "Gather wild za'atar, mountain olive oil, and wheat flour for Teta Nahla's morning bake.",
            "id": "LB-1-gather",
            "needs": [
              {
                "count": 2,
                "item": "zaatar"
              },
              {
                "count": 1,
                "item": "olive_oil"
              },
              {
                "count": 2,
                "item": "flour"
              }
            ],
            "title_en": "Pantry & Terrace Harvest",
            "type": "gather"
          },
          {
            "goal_en": "Help Teta Nahla shape the dough, brush on olive oil and za'atar, and bake a warm manoushe on the saj.",
            "id": "LB-1-cook",
            "recipe": {
              "inputs": [
                "flour",
                "olive_oil",
                "zaatar"
              ],
              "output": "manoushe"
            },
            "title_en": "Bake Saj Manoushe",
            "type": "cook"
          },
          {
            "blueprint": [
              "RRRR",
              "CCCC",
              "L..L",
              "LLLL"
            ],
            "blueprintLegend": {
              "C": "cedar_beam",
              "L": "limestone_block",
              "R": "red_tile"
            },
            "goal_en": "Arrange the red terracotta roof tiles, cedar beams, and pale limestone blocks to repair the courtyard archway.",
            "id": "LB-1-build",
            "title_en": "Restore the Mountain Stone House",
            "type": "build"
          },
          {
            "goal_en": "Share a warm manoushe at the Byblos market in exchange for a jar of tangy crimson sumac.",
            "id": "LB-1-trade",
            "needs": [
              {
                "count": 1,
                "item": "manoushe"
              }
            ],
            "reward": {
              "count": 1,
              "item": "sumac_jar"
            },
            "title_en": "Share with the Souk Spice Merchant",
            "type": "trade"
          },
          {
            "goal_en": "Practice three Lebanese Arabic words with Teta Nahla before breakfast is served.",
            "id": "LB-1-word",
            "title_en": "Words from Teta's Kitchen",
            "type": "word",
            "words": [
              {
                "en": "grandma",
                "translit": "tēta",
                "word": "تيتا"
              },
              {
                "en": "flatbread topped with za'atar and olive oil",
                "translit": "manʾūshe",
                "word": "منقوشة"
              },
              {
                "en": "bon appétit (double health)",
                "translit": "ṣaḥtēn",
                "word": "صحتين"
              }
            ]
          }
        ],
        "id": 1,
        "title_en": "Summer at Teta's"
      }
    ],
    "colors": {
      "primary": "#1E5631",
      "secondary": "#C97A40"
    },
    "country": "LB",
    "items": [
      {
        "color": "#7B4B2A",
        "id": "cedar_beam",
        "name_en": "Cedar Wood Beam"
      },
      {
        "color": "#F5ECD7",
        "id": "flour",
        "name_en": "Wheat Flour"
      },
      {
        "color": "#E6DEC8",
        "id": "limestone_block",
        "name_en": "Pale Limestone Block"
      },
      {
        "color": "#D99B52",
        "id": "manoushe",
        "name_en": "Warm Za'atar Manoushe"
      },
      {
        "color": "#B5A642",
        "id": "olive_oil",
        "name_en": "Mountain Olive Oil"
      },
      {
        "color": "#B84A39",
        "id": "red_tile",
        "name_en": "Red Terracotta Roof Tile"
      },
      {
        "color": "#8B2635",
        "id": "sumac_jar",
        "name_en": "Jar of Crimson Sumac"
      },
      {
        "color": "#556B2F",
        "id": "zaatar",
        "name_en": "Wild Za'atar Blend"
      }
    ],
    "lang": "ar-LB",
    "mentor": {
      "greeting": "أهلا وسهلا يا تيتا! فوت عالحوش، الصاج عم يحمى لنعمل أطيب منقوشة.",
      "greeting_en": "Welcome, habibi! Come into the courtyard—the saj is warming up for fresh manoushe.",
      "name": "Teta Nahla"
    },
    "name_en": "Lebanon",
    "regions": [
      {
        "id": "byblos",
        "name_en": "Byblos"
      },
      {
        "id": "mount_lebanon",
        "name_en": "Mount Lebanon"
      },
      {
        "id": "beirut",
        "name_en": "Beirut"
      }
    ]
  }
];

export function getMinecraftItemId(country: string, itemId: string): string {
  return `miraverse:${country.toLowerCase()}_${itemId}`;
}
