// GENERATED FILE - DO NOT EDIT
export const V04_SCHEMA_VERSION = 4 as const;
export const V04_COMPILER_VERSION = "0.4.0" as const;
export const V04_SOURCE_CONTENT_HASH = "baa5d17817a157e5" as const;
export const V04_QUESTS = [
  {
    "questId": "EG:ch1:lantern:main",
    "country": "EG",
    "chapter": 1,
    "titleEn": "Lanterns on the Nile",
    "titleNative": "مصر · القاهرة",
    "synopsis": "Welcome, my dear! You have lit up Egypt—come, let's make a warm bowl of koshari and hang the Nile lanterns together.",
    "mentorId": "npc:EG:teta_samira",
    "mentorName": "Teta Samira",
    "landmarkId": "landmark:EG:main",
    "objectives": [
      {
        "objectiveId": "EG:ch1:lantern:gather",
        "challengeType": "gather",
        "title": "Pantry on the Corniche",
        "description": "Collect rice, brown lentils, and spiced tomato sauce from the market stalls for Teta Samira's koshari pot.",
        "targetNpcId": "npc:EG:teta_samira",
        "targetStationId": "station:EG:gather",
        "requiredItems": [
          {
            "itemId": "item:EG:rice",
            "quantity": 1,
            "labelEn": "Egyptian Short-Grain Rice",
            "labelNative": "Egyptian Short-Grain Rice"
          },
          {
            "itemId": "item:EG:lentils",
            "quantity": 1,
            "labelEn": "Brown Lentils",
            "labelNative": "Brown Lentils"
          },
          {
            "itemId": "item:EG:tomato_sauce",
            "quantity": 1,
            "labelEn": "Spiced Garlic Tomato Sauce",
            "labelNative": "Spiced Garlic Tomato Sauce"
          }
        ],
        "rewardItems": [
          {
            "itemId": "item:EG:gather_token",
            "quantity": 1,
            "labelEn": "Egypt GATHER Keepsake"
          }
        ],
        "miraTokenReward": 20,
        "culturalFact": "Welcome, my dear! You have lit up Egypt—come, let's make a warm bowl of koshari and hang the Nile lanterns together.",
        "vocabWords": [
          {
            "word": "Egyptian Short-Grain Rice",
            "translit": "rice",
            "en": "Egyptian Short-Grain Rice",
            "objectId": "prop:EG:word_1"
          },
          {
            "word": "Brown Lentils",
            "translit": "lentils",
            "en": "Brown Lentils",
            "objectId": "prop:EG:word_2"
          },
          {
            "word": "Spiced Garlic Tomato Sauce",
            "translit": "tomato sauce",
            "en": "Spiced Garlic Tomato Sauce",
            "objectId": "prop:EG:word_3"
          }
        ]
      },
      {
        "objectiveId": "EG:ch1:lantern:trade",
        "challengeType": "trade",
        "title": "Lanterns of Khan el-Khalili",
        "description": "Share a warm bowl of homemade koshari with the bazaar artisan in exchange for a brass fanous lantern.",
        "targetNpcId": "npc:EG:teta_samira",
        "targetStationId": "station:EG:trade",
        "requiredItems": [
          {
            "itemId": "item:EG:rice",
            "quantity": 1,
            "labelEn": "Egyptian Short-Grain Rice",
            "labelNative": "Egyptian Short-Grain Rice"
          },
          {
            "itemId": "item:EG:lentils",
            "quantity": 1,
            "labelEn": "Brown Lentils",
            "labelNative": "Brown Lentils"
          },
          {
            "itemId": "item:EG:tomato_sauce",
            "quantity": 1,
            "labelEn": "Spiced Garlic Tomato Sauce",
            "labelNative": "Spiced Garlic Tomato Sauce"
          }
        ],
        "rewardItems": [
          {
            "itemId": "item:EG:trade_token",
            "quantity": 1,
            "labelEn": "Egypt TRADE Keepsake"
          }
        ],
        "miraTokenReward": 20,
        "culturalFact": "Welcome, my dear! You have lit up Egypt—come, let's make a warm bowl of koshari and hang the Nile lanterns together.",
        "vocabWords": [
          {
            "word": "Egyptian Short-Grain Rice",
            "translit": "rice",
            "en": "Egyptian Short-Grain Rice",
            "objectId": "prop:EG:word_1"
          },
          {
            "word": "Brown Lentils",
            "translit": "lentils",
            "en": "Brown Lentils",
            "objectId": "prop:EG:word_2"
          },
          {
            "word": "Spiced Garlic Tomato Sauce",
            "translit": "tomato sauce",
            "en": "Spiced Garlic Tomato Sauce",
            "objectId": "prop:EG:word_3"
          }
        ]
      },
      {
        "objectiveId": "EG:ch1:lantern:build",
        "challengeType": "build",
        "title": "Felucca on the Nile",
        "description": "Assemble a traditional wooden Nile felucca hull with acacia planks and hoist its tall white linen sail.",
        "targetNpcId": "npc:EG:teta_samira",
        "targetStationId": "station:EG:build",
        "requiredItems": [
          {
            "itemId": "item:EG:rice",
            "quantity": 1,
            "labelEn": "Egyptian Short-Grain Rice",
            "labelNative": "Egyptian Short-Grain Rice"
          },
          {
            "itemId": "item:EG:lentils",
            "quantity": 1,
            "labelEn": "Brown Lentils",
            "labelNative": "Brown Lentils"
          },
          {
            "itemId": "item:EG:tomato_sauce",
            "quantity": 1,
            "labelEn": "Spiced Garlic Tomato Sauce",
            "labelNative": "Spiced Garlic Tomato Sauce"
          }
        ],
        "rewardItems": [
          {
            "itemId": "item:EG:build_token",
            "quantity": 1,
            "labelEn": "Egypt BUILD Keepsake"
          }
        ],
        "miraTokenReward": 20,
        "culturalFact": "Welcome, my dear! You have lit up Egypt—come, let's make a warm bowl of koshari and hang the Nile lanterns together.",
        "vocabWords": [
          {
            "word": "Egyptian Short-Grain Rice",
            "translit": "rice",
            "en": "Egyptian Short-Grain Rice",
            "objectId": "prop:EG:word_1"
          },
          {
            "word": "Brown Lentils",
            "translit": "lentils",
            "en": "Brown Lentils",
            "objectId": "prop:EG:word_2"
          },
          {
            "word": "Spiced Garlic Tomato Sauce",
            "translit": "tomato sauce",
            "en": "Spiced Garlic Tomato Sauce",
            "objectId": "prop:EG:word_3"
          }
        ]
      },
      {
        "objectiveId": "EG:ch1:lantern:cook",
        "challengeType": "cook",
        "title": "Teta Samira's Koshari",
        "description": "Layer the rice, lentils, spiced tomato sauce, and golden crispy onions in order to prepare a festive bowl of Egyptian koshari.",
        "targetNpcId": "npc:EG:teta_samira",
        "targetStationId": "station:EG:cook",
        "requiredItems": [
          {
            "itemId": "item:EG:rice",
            "quantity": 1,
            "labelEn": "Egyptian Short-Grain Rice",
            "labelNative": "Egyptian Short-Grain Rice"
          },
          {
            "itemId": "item:EG:lentils",
            "quantity": 1,
            "labelEn": "Brown Lentils",
            "labelNative": "Brown Lentils"
          },
          {
            "itemId": "item:EG:tomato_sauce",
            "quantity": 1,
            "labelEn": "Spiced Garlic Tomato Sauce",
            "labelNative": "Spiced Garlic Tomato Sauce"
          }
        ],
        "rewardItems": [
          {
            "itemId": "item:EG:cook_token",
            "quantity": 1,
            "labelEn": "Egypt COOK Keepsake"
          }
        ],
        "miraTokenReward": 20,
        "culturalFact": "Welcome, my dear! You have lit up Egypt—come, let's make a warm bowl of koshari and hang the Nile lanterns together.",
        "vocabWords": [
          {
            "word": "Egyptian Short-Grain Rice",
            "translit": "rice",
            "en": "Egyptian Short-Grain Rice",
            "objectId": "prop:EG:word_1"
          },
          {
            "word": "Brown Lentils",
            "translit": "lentils",
            "en": "Brown Lentils",
            "objectId": "prop:EG:word_2"
          },
          {
            "word": "Spiced Garlic Tomato Sauce",
            "translit": "tomato sauce",
            "en": "Spiced Garlic Tomato Sauce",
            "objectId": "prop:EG:word_3"
          }
        ]
      },
      {
        "objectiveId": "EG:ch1:lantern:word",
        "challengeType": "word",
        "title": "Words from Cairo",
        "description": "Practice three everyday Cairene Egyptian Arabic words with Teta Samira before the evening river boat sets sail.",
        "targetNpcId": "npc:EG:teta_samira",
        "targetStationId": "station:EG:word",
        "requiredItems": [
          {
            "itemId": "item:EG:rice",
            "quantity": 1,
            "labelEn": "Egyptian Short-Grain Rice",
            "labelNative": "Egyptian Short-Grain Rice"
          },
          {
            "itemId": "item:EG:lentils",
            "quantity": 1,
            "labelEn": "Brown Lentils",
            "labelNative": "Brown Lentils"
          },
          {
            "itemId": "item:EG:tomato_sauce",
            "quantity": 1,
            "labelEn": "Spiced Garlic Tomato Sauce",
            "labelNative": "Spiced Garlic Tomato Sauce"
          }
        ],
        "rewardItems": [
          {
            "itemId": "item:EG:word_token",
            "quantity": 1,
            "labelEn": "Egypt WORD Keepsake"
          }
        ],
        "miraTokenReward": 20,
        "culturalFact": "Welcome, my dear! You have lit up Egypt—come, let's make a warm bowl of koshari and hang the Nile lanterns together.",
        "vocabWords": [
          {
            "word": "Egyptian Short-Grain Rice",
            "translit": "rice",
            "en": "Egyptian Short-Grain Rice",
            "objectId": "prop:EG:word_1"
          },
          {
            "word": "Brown Lentils",
            "translit": "lentils",
            "en": "Brown Lentils",
            "objectId": "prop:EG:word_2"
          },
          {
            "word": "Spiced Garlic Tomato Sauce",
            "translit": "tomato sauce",
            "en": "Spiced Garlic Tomato Sauce",
            "objectId": "prop:EG:word_3"
          }
        ]
      }
    ],
    "completionReward": {
      "rewardId": "reward:EG:ch1_keepsake",
      "keepsakeNameEn": "Khan Courtyard & Fanous Archway Golden Keepsake",
      "keepsakeNameNative": "مصر · القاهرة",
      "miraTokensBonus": 50,
      "stampChapter": 1
    }
  },
  {
    "questId": "FR:ch1:bakery:main",
    "country": "FR",
    "chapter": 1,
    "titleEn": "The Golden Galette of Lyon",
    "titleNative": "France · Vieux Lyon",
    "synopsis": "Welcome to my kitchen in Lyon! Let us bake a warm golden galette des rois together.",
    "mentorId": "npc:FR:mamie_claire",
    "mentorName": "Mamie Claire",
    "landmarkId": "landmark:FR:main",
    "objectives": [
      {
        "objectiveId": "FR:ch1:bakery:gather",
        "challengeType": "gather",
        "title": "Market Day at Les Halles",
        "description": "Gather flaky puff pastry, sweet almond cream, and a tiny porcelain fève charm for Mamie Claire.",
        "targetNpcId": "npc:FR:mamie_claire",
        "targetStationId": "station:FR:gather",
        "requiredItems": [
          {
            "itemId": "item:FR:puff_pastry",
            "quantity": 1,
            "labelEn": "Flaky Puff Pastry",
            "labelNative": "Flaky Puff Pastry"
          },
          {
            "itemId": "item:FR:almond_cream",
            "quantity": 1,
            "labelEn": "Sweet Almond Cream",
            "labelNative": "Sweet Almond Cream"
          },
          {
            "itemId": "item:FR:porcelain_feve",
            "quantity": 1,
            "labelEn": "Porcelain Fève Charm",
            "labelNative": "Porcelain Fève Charm"
          }
        ],
        "rewardItems": [
          {
            "itemId": "item:FR:gather_token",
            "quantity": 1,
            "labelEn": "France GATHER Keepsake"
          }
        ],
        "miraTokenReward": 20,
        "culturalFact": "Welcome to my kitchen in Lyon! Let us bake a warm golden galette des rois together.",
        "vocabWords": [
          {
            "word": "Flaky Puff Pastry",
            "translit": "puff pastry",
            "en": "Flaky Puff Pastry",
            "objectId": "prop:FR:word_1"
          },
          {
            "word": "Sweet Almond Cream",
            "translit": "almond cream",
            "en": "Sweet Almond Cream",
            "objectId": "prop:FR:word_2"
          },
          {
            "word": "Porcelain Fève Charm",
            "translit": "porcelain feve",
            "en": "Porcelain Fève Charm",
            "objectId": "prop:FR:word_3"
          }
        ]
      },
      {
        "objectiveId": "FR:ch1:bakery:trade",
        "challengeType": "trade",
        "title": "Sharing the Epiphany Treat",
        "description": "Share a warm Galette des Rois with the neighborhood baker in exchange for a festive Golden Paper Crown.",
        "targetNpcId": "npc:FR:mamie_claire",
        "targetStationId": "station:FR:trade",
        "requiredItems": [
          {
            "itemId": "item:FR:puff_pastry",
            "quantity": 1,
            "labelEn": "Flaky Puff Pastry",
            "labelNative": "Flaky Puff Pastry"
          },
          {
            "itemId": "item:FR:almond_cream",
            "quantity": 1,
            "labelEn": "Sweet Almond Cream",
            "labelNative": "Sweet Almond Cream"
          },
          {
            "itemId": "item:FR:porcelain_feve",
            "quantity": 1,
            "labelEn": "Porcelain Fève Charm",
            "labelNative": "Porcelain Fève Charm"
          }
        ],
        "rewardItems": [
          {
            "itemId": "item:FR:trade_token",
            "quantity": 1,
            "labelEn": "France TRADE Keepsake"
          }
        ],
        "miraTokenReward": 20,
        "culturalFact": "Welcome to my kitchen in Lyon! Let us bake a warm golden galette des rois together.",
        "vocabWords": [
          {
            "word": "Flaky Puff Pastry",
            "translit": "puff pastry",
            "en": "Flaky Puff Pastry",
            "objectId": "prop:FR:word_1"
          },
          {
            "word": "Sweet Almond Cream",
            "translit": "almond cream",
            "en": "Sweet Almond Cream",
            "objectId": "prop:FR:word_2"
          },
          {
            "word": "Porcelain Fève Charm",
            "translit": "porcelain feve",
            "en": "Porcelain Fève Charm",
            "objectId": "prop:FR:word_3"
          }
        ]
      },
      {
        "objectiveId": "FR:ch1:bakery:build",
        "challengeType": "build",
        "title": "The Vieux Lyon Bakery Facade",
        "description": "Restore the neighborhood boulangerie facade with slate roof tiles, limestone walls, and oak shutters.",
        "targetNpcId": "npc:FR:mamie_claire",
        "targetStationId": "station:FR:build",
        "requiredItems": [
          {
            "itemId": "item:FR:puff_pastry",
            "quantity": 1,
            "labelEn": "Flaky Puff Pastry",
            "labelNative": "Flaky Puff Pastry"
          },
          {
            "itemId": "item:FR:almond_cream",
            "quantity": 1,
            "labelEn": "Sweet Almond Cream",
            "labelNative": "Sweet Almond Cream"
          },
          {
            "itemId": "item:FR:porcelain_feve",
            "quantity": 1,
            "labelEn": "Porcelain Fève Charm",
            "labelNative": "Porcelain Fève Charm"
          }
        ],
        "rewardItems": [
          {
            "itemId": "item:FR:build_token",
            "quantity": 1,
            "labelEn": "France BUILD Keepsake"
          }
        ],
        "miraTokenReward": 20,
        "culturalFact": "Welcome to my kitchen in Lyon! Let us bake a warm golden galette des rois together.",
        "vocabWords": [
          {
            "word": "Flaky Puff Pastry",
            "translit": "puff pastry",
            "en": "Flaky Puff Pastry",
            "objectId": "prop:FR:word_1"
          },
          {
            "word": "Sweet Almond Cream",
            "translit": "almond cream",
            "en": "Sweet Almond Cream",
            "objectId": "prop:FR:word_2"
          },
          {
            "word": "Porcelain Fève Charm",
            "translit": "porcelain feve",
            "en": "Porcelain Fève Charm",
            "objectId": "prop:FR:word_3"
          }
        ]
      },
      {
        "objectiveId": "FR:ch1:bakery:cook",
        "challengeType": "cook",
        "title": "Baking the Galette des Rois",
        "description": "Layer the puff pastry with almond cream, tuck in the porcelain fève, and help Mamie Claire bake the golden galette.",
        "targetNpcId": "npc:FR:mamie_claire",
        "targetStationId": "station:FR:cook",
        "requiredItems": [
          {
            "itemId": "item:FR:puff_pastry",
            "quantity": 1,
            "labelEn": "Flaky Puff Pastry",
            "labelNative": "Flaky Puff Pastry"
          },
          {
            "itemId": "item:FR:almond_cream",
            "quantity": 1,
            "labelEn": "Sweet Almond Cream",
            "labelNative": "Sweet Almond Cream"
          },
          {
            "itemId": "item:FR:porcelain_feve",
            "quantity": 1,
            "labelEn": "Porcelain Fève Charm",
            "labelNative": "Porcelain Fève Charm"
          }
        ],
        "rewardItems": [
          {
            "itemId": "item:FR:cook_token",
            "quantity": 1,
            "labelEn": "France COOK Keepsake"
          }
        ],
        "miraTokenReward": 20,
        "culturalFact": "Welcome to my kitchen in Lyon! Let us bake a warm golden galette des rois together.",
        "vocabWords": [
          {
            "word": "Flaky Puff Pastry",
            "translit": "puff pastry",
            "en": "Flaky Puff Pastry",
            "objectId": "prop:FR:word_1"
          },
          {
            "word": "Sweet Almond Cream",
            "translit": "almond cream",
            "en": "Sweet Almond Cream",
            "objectId": "prop:FR:word_2"
          },
          {
            "word": "Porcelain Fève Charm",
            "translit": "porcelain feve",
            "en": "Porcelain Fève Charm",
            "objectId": "prop:FR:word_3"
          }
        ]
      },
      {
        "objectiveId": "FR:ch1:bakery:word",
        "challengeType": "word",
        "title": "French Bakery Words",
        "description": "Learn three everyday French words from Mamie Claire's kitchen in Lyon.",
        "targetNpcId": "npc:FR:mamie_claire",
        "targetStationId": "station:FR:word",
        "requiredItems": [
          {
            "itemId": "item:FR:puff_pastry",
            "quantity": 1,
            "labelEn": "Flaky Puff Pastry",
            "labelNative": "Flaky Puff Pastry"
          },
          {
            "itemId": "item:FR:almond_cream",
            "quantity": 1,
            "labelEn": "Sweet Almond Cream",
            "labelNative": "Sweet Almond Cream"
          },
          {
            "itemId": "item:FR:porcelain_feve",
            "quantity": 1,
            "labelEn": "Porcelain Fève Charm",
            "labelNative": "Porcelain Fève Charm"
          }
        ],
        "rewardItems": [
          {
            "itemId": "item:FR:word_token",
            "quantity": 1,
            "labelEn": "France WORD Keepsake"
          }
        ],
        "miraTokenReward": 20,
        "culturalFact": "Welcome to my kitchen in Lyon! Let us bake a warm golden galette des rois together.",
        "vocabWords": [
          {
            "word": "Flaky Puff Pastry",
            "translit": "puff pastry",
            "en": "Flaky Puff Pastry",
            "objectId": "prop:FR:word_1"
          },
          {
            "word": "Sweet Almond Cream",
            "translit": "almond cream",
            "en": "Sweet Almond Cream",
            "objectId": "prop:FR:word_2"
          },
          {
            "word": "Porcelain Fève Charm",
            "translit": "porcelain feve",
            "en": "Porcelain Fève Charm",
            "objectId": "prop:FR:word_3"
          }
        ]
      }
    ],
    "completionReward": {
      "rewardId": "reward:FR:ch1_keepsake",
      "keepsakeNameEn": "Boulangerie du Soleil Golden Keepsake",
      "keepsakeNameNative": "France · Vieux Lyon",
      "miraTokensBonus": 50,
      "stampChapter": 1
    }
  },
  {
    "questId": "IQ:ch1:shanasheel:main",
    "country": "IQ",
    "chapter": 1,
    "titleEn": "Eid by the Tigris",
    "titleNative": "العراق · بغداد",
    "synopsis": "Welcome, my dears! Come bake Eid kleicha and drink cardamom tea in the courtyard.",
    "mentorId": "npc:IQ:bibi_amal",
    "mentorName": "Bibi Amal",
    "landmarkId": "landmark:IQ:main",
    "objectives": [
      {
        "objectiveId": "IQ:ch1:shanasheel:gather",
        "challengeType": "gather",
        "title": "Pantry by the Tigris",
        "description": "Gather warm wheat dough, sweet date paste, and fragrant cardamom with Bibi Amal for the Eid baking tray.",
        "targetNpcId": "npc:IQ:bibi_amal",
        "targetStationId": "station:IQ:gather",
        "requiredItems": [
          {
            "itemId": "item:IQ:wheat_dough",
            "quantity": 1,
            "labelEn": "Wheat Dough",
            "labelNative": "Wheat Dough"
          },
          {
            "itemId": "item:IQ:date_paste",
            "quantity": 1,
            "labelEn": "Date Paste",
            "labelNative": "Date Paste"
          },
          {
            "itemId": "item:IQ:cardamom",
            "quantity": 1,
            "labelEn": "Ground Cardamom",
            "labelNative": "Ground Cardamom"
          }
        ],
        "rewardItems": [
          {
            "itemId": "item:IQ:gather_token",
            "quantity": 1,
            "labelEn": "Iraq GATHER Keepsake"
          }
        ],
        "miraTokenReward": 20,
        "culturalFact": "Welcome, my dears! Come bake Eid kleicha and drink cardamom tea in the courtyard.",
        "vocabWords": [
          {
            "word": "Wheat Dough",
            "translit": "wheat dough",
            "en": "Wheat Dough",
            "objectId": "prop:IQ:word_1"
          },
          {
            "word": "Date Paste",
            "translit": "date paste",
            "en": "Date Paste",
            "objectId": "prop:IQ:word_2"
          },
          {
            "word": "Ground Cardamom",
            "translit": "cardamom",
            "en": "Ground Cardamom",
            "objectId": "prop:IQ:word_3"
          }
        ]
      },
      {
        "objectiveId": "IQ:ch1:shanasheel:trade",
        "challengeType": "trade",
        "title": "Tea in Al-Mutanabbi",
        "description": "Share a plate of fresh Eid kleicha with the neighborhood coppersmith in exchange for a polished brass teapot.",
        "targetNpcId": "npc:IQ:bibi_amal",
        "targetStationId": "station:IQ:trade",
        "requiredItems": [
          {
            "itemId": "item:IQ:wheat_dough",
            "quantity": 1,
            "labelEn": "Wheat Dough",
            "labelNative": "Wheat Dough"
          },
          {
            "itemId": "item:IQ:date_paste",
            "quantity": 1,
            "labelEn": "Date Paste",
            "labelNative": "Date Paste"
          },
          {
            "itemId": "item:IQ:cardamom",
            "quantity": 1,
            "labelEn": "Ground Cardamom",
            "labelNative": "Ground Cardamom"
          }
        ],
        "rewardItems": [
          {
            "itemId": "item:IQ:trade_token",
            "quantity": 1,
            "labelEn": "Iraq TRADE Keepsake"
          }
        ],
        "miraTokenReward": 20,
        "culturalFact": "Welcome, my dears! Come bake Eid kleicha and drink cardamom tea in the courtyard.",
        "vocabWords": [
          {
            "word": "Wheat Dough",
            "translit": "wheat dough",
            "en": "Wheat Dough",
            "objectId": "prop:IQ:word_1"
          },
          {
            "word": "Date Paste",
            "translit": "date paste",
            "en": "Date Paste",
            "objectId": "prop:IQ:word_2"
          },
          {
            "word": "Ground Cardamom",
            "translit": "cardamom",
            "en": "Ground Cardamom",
            "objectId": "prop:IQ:word_3"
          }
        ]
      },
      {
        "objectiveId": "IQ:ch1:shanasheel:build",
        "challengeType": "build",
        "title": "Baghdadi Courtyard House",
        "description": "Lay the mud-brick walls, palm-wood shanashil beams, and turquoise tiles around the family courtyard.",
        "targetNpcId": "npc:IQ:bibi_amal",
        "targetStationId": "station:IQ:build",
        "requiredItems": [
          {
            "itemId": "item:IQ:wheat_dough",
            "quantity": 1,
            "labelEn": "Wheat Dough",
            "labelNative": "Wheat Dough"
          },
          {
            "itemId": "item:IQ:date_paste",
            "quantity": 1,
            "labelEn": "Date Paste",
            "labelNative": "Date Paste"
          },
          {
            "itemId": "item:IQ:cardamom",
            "quantity": 1,
            "labelEn": "Ground Cardamom",
            "labelNative": "Ground Cardamom"
          }
        ],
        "rewardItems": [
          {
            "itemId": "item:IQ:build_token",
            "quantity": 1,
            "labelEn": "Iraq BUILD Keepsake"
          }
        ],
        "miraTokenReward": 20,
        "culturalFact": "Welcome, my dears! Come bake Eid kleicha and drink cardamom tea in the courtyard.",
        "vocabWords": [
          {
            "word": "Wheat Dough",
            "translit": "wheat dough",
            "en": "Wheat Dough",
            "objectId": "prop:IQ:word_1"
          },
          {
            "word": "Date Paste",
            "translit": "date paste",
            "en": "Date Paste",
            "objectId": "prop:IQ:word_2"
          },
          {
            "word": "Ground Cardamom",
            "translit": "cardamom",
            "en": "Ground Cardamom",
            "objectId": "prop:IQ:word_3"
          }
        ]
      },
      {
        "objectiveId": "IQ:ch1:shanasheel:cook",
        "challengeType": "cook",
        "title": "Bake the Eid Kleicha",
        "description": "Roll the spiced wheat dough around the date paste and cardamom filling so Bibi Amal can bake golden kleicha cookies.",
        "targetNpcId": "npc:IQ:bibi_amal",
        "targetStationId": "station:IQ:cook",
        "requiredItems": [
          {
            "itemId": "item:IQ:wheat_dough",
            "quantity": 1,
            "labelEn": "Wheat Dough",
            "labelNative": "Wheat Dough"
          },
          {
            "itemId": "item:IQ:date_paste",
            "quantity": 1,
            "labelEn": "Date Paste",
            "labelNative": "Date Paste"
          },
          {
            "itemId": "item:IQ:cardamom",
            "quantity": 1,
            "labelEn": "Ground Cardamom",
            "labelNative": "Ground Cardamom"
          }
        ],
        "rewardItems": [
          {
            "itemId": "item:IQ:cook_token",
            "quantity": 1,
            "labelEn": "Iraq COOK Keepsake"
          }
        ],
        "miraTokenReward": 20,
        "culturalFact": "Welcome, my dears! Come bake Eid kleicha and drink cardamom tea in the courtyard.",
        "vocabWords": [
          {
            "word": "Wheat Dough",
            "translit": "wheat dough",
            "en": "Wheat Dough",
            "objectId": "prop:IQ:word_1"
          },
          {
            "word": "Date Paste",
            "translit": "date paste",
            "en": "Date Paste",
            "objectId": "prop:IQ:word_2"
          },
          {
            "word": "Ground Cardamom",
            "translit": "cardamom",
            "en": "Ground Cardamom",
            "objectId": "prop:IQ:word_3"
          }
        ]
      },
      {
        "objectiveId": "IQ:ch1:shanasheel:word",
        "challengeType": "word",
        "title": "Words from Bibi's Courtyard",
        "description": "Learn three Baghdadi Iraqi Arabic words used during family Eid gatherings.",
        "targetNpcId": "npc:IQ:bibi_amal",
        "targetStationId": "station:IQ:word",
        "requiredItems": [
          {
            "itemId": "item:IQ:wheat_dough",
            "quantity": 1,
            "labelEn": "Wheat Dough",
            "labelNative": "Wheat Dough"
          },
          {
            "itemId": "item:IQ:date_paste",
            "quantity": 1,
            "labelEn": "Date Paste",
            "labelNative": "Date Paste"
          },
          {
            "itemId": "item:IQ:cardamom",
            "quantity": 1,
            "labelEn": "Ground Cardamom",
            "labelNative": "Ground Cardamom"
          }
        ],
        "rewardItems": [
          {
            "itemId": "item:IQ:word_token",
            "quantity": 1,
            "labelEn": "Iraq WORD Keepsake"
          }
        ],
        "miraTokenReward": 20,
        "culturalFact": "Welcome, my dears! Come bake Eid kleicha and drink cardamom tea in the courtyard.",
        "vocabWords": [
          {
            "word": "Wheat Dough",
            "translit": "wheat dough",
            "en": "Wheat Dough",
            "objectId": "prop:IQ:word_1"
          },
          {
            "word": "Date Paste",
            "translit": "date paste",
            "en": "Date Paste",
            "objectId": "prop:IQ:word_2"
          },
          {
            "word": "Ground Cardamom",
            "translit": "cardamom",
            "en": "Ground Cardamom",
            "objectId": "prop:IQ:word_3"
          }
        ]
      }
    ],
    "completionReward": {
      "rewardId": "reward:IQ:ch1_keepsake",
      "keepsakeNameEn": "Tigris Shanasheel Courtyard House Golden Keepsake",
      "keepsakeNameNative": "العراق · بغداد",
      "miraTokensBonus": 50,
      "stampChapter": 1
    }
  },
  {
    "questId": "KR:ch1:hanok:main",
    "country": "KR",
    "chapter": 1,
    "titleEn": "Harvest Moon in Jeonju",
    "titleNative": "대한민국 · 전주 한옥마을",
    "synopsis": "Welcome, sweet grandchild! Let's shape warm songpyeon together under the bright harvest moon in Jeonju.",
    "mentorId": "npc:KR:halmeoni",
    "mentorName": "Halmeoni",
    "landmarkId": "landmark:KR:main",
    "objectives": [
      {
        "objectiveId": "KR:ch1:hanok:gather",
        "challengeType": "gather",
        "title": "Chuseok Basket in Jeonju",
        "description": "Gather freshly milled rice flour, sweet sesame-honey filling, and fragrant pine needles for the courtyard steamer.",
        "targetNpcId": "npc:KR:halmeoni",
        "targetStationId": "station:KR:gather",
        "requiredItems": [
          {
            "itemId": "item:KR:rice_flour",
            "quantity": 1,
            "labelEn": "Rice Flour",
            "labelNative": "Rice Flour"
          },
          {
            "itemId": "item:KR:sesame_honey",
            "quantity": 1,
            "labelEn": "Sesame & Honey Filling",
            "labelNative": "Sesame & Honey Filling"
          },
          {
            "itemId": "item:KR:pine_needles",
            "quantity": 1,
            "labelEn": "Fresh Pine Needles",
            "labelNative": "Fresh Pine Needles"
          }
        ],
        "rewardItems": [
          {
            "itemId": "item:KR:gather_token",
            "quantity": 1,
            "labelEn": "South Korea GATHER Keepsake"
          }
        ],
        "miraTokenReward": 20,
        "culturalFact": "Welcome, sweet grandchild! Let's shape warm songpyeon together under the bright harvest moon in Jeonju.",
        "vocabWords": [
          {
            "word": "Rice Flour",
            "translit": "rice flour",
            "en": "Rice Flour",
            "objectId": "prop:KR:word_1"
          },
          {
            "word": "Sesame & Honey Filling",
            "translit": "sesame honey",
            "en": "Sesame & Honey Filling",
            "objectId": "prop:KR:word_2"
          },
          {
            "word": "Fresh Pine Needles",
            "translit": "pine needles",
            "en": "Fresh Pine Needles",
            "objectId": "prop:KR:word_3"
          }
        ]
      },
      {
        "objectiveId": "KR:ch1:hanok:trade",
        "challengeType": "trade",
        "title": "Share Chuseok Songpyeon",
        "description": "Offer a plate of warm songpyeon to the neighborhood potter and receive an inlaid celadon tea cup in return.",
        "targetNpcId": "npc:KR:halmeoni",
        "targetStationId": "station:KR:trade",
        "requiredItems": [
          {
            "itemId": "item:KR:rice_flour",
            "quantity": 1,
            "labelEn": "Rice Flour",
            "labelNative": "Rice Flour"
          },
          {
            "itemId": "item:KR:sesame_honey",
            "quantity": 1,
            "labelEn": "Sesame & Honey Filling",
            "labelNative": "Sesame & Honey Filling"
          },
          {
            "itemId": "item:KR:pine_needles",
            "quantity": 1,
            "labelEn": "Fresh Pine Needles",
            "labelNative": "Fresh Pine Needles"
          }
        ],
        "rewardItems": [
          {
            "itemId": "item:KR:trade_token",
            "quantity": 1,
            "labelEn": "South Korea TRADE Keepsake"
          }
        ],
        "miraTokenReward": 20,
        "culturalFact": "Welcome, sweet grandchild! Let's shape warm songpyeon together under the bright harvest moon in Jeonju.",
        "vocabWords": [
          {
            "word": "Rice Flour",
            "translit": "rice flour",
            "en": "Rice Flour",
            "objectId": "prop:KR:word_1"
          },
          {
            "word": "Sesame & Honey Filling",
            "translit": "sesame honey",
            "en": "Sesame & Honey Filling",
            "objectId": "prop:KR:word_2"
          },
          {
            "word": "Fresh Pine Needles",
            "translit": "pine needles",
            "en": "Fresh Pine Needles",
            "objectId": "prop:KR:word_3"
          }
        ]
      },
      {
        "objectiveId": "KR:ch1:hanok:build",
        "challengeType": "build",
        "title": "Restore the Hanok Courtyard Pavilion",
        "description": "Arrange curved giwa roof tiles above sturdy pine pillars and warm hanji paper doors.",
        "targetNpcId": "npc:KR:halmeoni",
        "targetStationId": "station:KR:build",
        "requiredItems": [
          {
            "itemId": "item:KR:rice_flour",
            "quantity": 1,
            "labelEn": "Rice Flour",
            "labelNative": "Rice Flour"
          },
          {
            "itemId": "item:KR:sesame_honey",
            "quantity": 1,
            "labelEn": "Sesame & Honey Filling",
            "labelNative": "Sesame & Honey Filling"
          },
          {
            "itemId": "item:KR:pine_needles",
            "quantity": 1,
            "labelEn": "Fresh Pine Needles",
            "labelNative": "Fresh Pine Needles"
          }
        ],
        "rewardItems": [
          {
            "itemId": "item:KR:build_token",
            "quantity": 1,
            "labelEn": "South Korea BUILD Keepsake"
          }
        ],
        "miraTokenReward": 20,
        "culturalFact": "Welcome, sweet grandchild! Let's shape warm songpyeon together under the bright harvest moon in Jeonju.",
        "vocabWords": [
          {
            "word": "Rice Flour",
            "translit": "rice flour",
            "en": "Rice Flour",
            "objectId": "prop:KR:word_1"
          },
          {
            "word": "Sesame & Honey Filling",
            "translit": "sesame honey",
            "en": "Sesame & Honey Filling",
            "objectId": "prop:KR:word_2"
          },
          {
            "word": "Fresh Pine Needles",
            "translit": "pine needles",
            "en": "Fresh Pine Needles",
            "objectId": "prop:KR:word_3"
          }
        ]
      },
      {
        "objectiveId": "KR:ch1:hanok:cook",
        "challengeType": "cook",
        "title": "Steam Half-Moon Songpyeon",
        "description": "Knead the rice flour dough, fold in the sesame-honey filling, and layer over pine needles so Halmeoni can steam the songpyeon.",
        "targetNpcId": "npc:KR:halmeoni",
        "targetStationId": "station:KR:cook",
        "requiredItems": [
          {
            "itemId": "item:KR:rice_flour",
            "quantity": 1,
            "labelEn": "Rice Flour",
            "labelNative": "Rice Flour"
          },
          {
            "itemId": "item:KR:sesame_honey",
            "quantity": 1,
            "labelEn": "Sesame & Honey Filling",
            "labelNative": "Sesame & Honey Filling"
          },
          {
            "itemId": "item:KR:pine_needles",
            "quantity": 1,
            "labelEn": "Fresh Pine Needles",
            "labelNative": "Fresh Pine Needles"
          }
        ],
        "rewardItems": [
          {
            "itemId": "item:KR:cook_token",
            "quantity": 1,
            "labelEn": "South Korea COOK Keepsake"
          }
        ],
        "miraTokenReward": 20,
        "culturalFact": "Welcome, sweet grandchild! Let's shape warm songpyeon together under the bright harvest moon in Jeonju.",
        "vocabWords": [
          {
            "word": "Rice Flour",
            "translit": "rice flour",
            "en": "Rice Flour",
            "objectId": "prop:KR:word_1"
          },
          {
            "word": "Sesame & Honey Filling",
            "translit": "sesame honey",
            "en": "Sesame & Honey Filling",
            "objectId": "prop:KR:word_2"
          },
          {
            "word": "Fresh Pine Needles",
            "translit": "pine needles",
            "en": "Fresh Pine Needles",
            "objectId": "prop:KR:word_3"
          }
        ]
      },
      {
        "objectiveId": "KR:ch1:hanok:word",
        "challengeType": "word",
        "title": "Jeonju Harvest Words",
        "description": "Learn three Korean words for Chuseok traditions in Jeonju.",
        "targetNpcId": "npc:KR:halmeoni",
        "targetStationId": "station:KR:word",
        "requiredItems": [
          {
            "itemId": "item:KR:rice_flour",
            "quantity": 1,
            "labelEn": "Rice Flour",
            "labelNative": "Rice Flour"
          },
          {
            "itemId": "item:KR:sesame_honey",
            "quantity": 1,
            "labelEn": "Sesame & Honey Filling",
            "labelNative": "Sesame & Honey Filling"
          },
          {
            "itemId": "item:KR:pine_needles",
            "quantity": 1,
            "labelEn": "Fresh Pine Needles",
            "labelNative": "Fresh Pine Needles"
          }
        ],
        "rewardItems": [
          {
            "itemId": "item:KR:word_token",
            "quantity": 1,
            "labelEn": "South Korea WORD Keepsake"
          }
        ],
        "miraTokenReward": 20,
        "culturalFact": "Welcome, sweet grandchild! Let's shape warm songpyeon together under the bright harvest moon in Jeonju.",
        "vocabWords": [
          {
            "word": "Rice Flour",
            "translit": "rice flour",
            "en": "Rice Flour",
            "objectId": "prop:KR:word_1"
          },
          {
            "word": "Sesame & Honey Filling",
            "translit": "sesame honey",
            "en": "Sesame & Honey Filling",
            "objectId": "prop:KR:word_2"
          },
          {
            "word": "Fresh Pine Needles",
            "translit": "pine needles",
            "en": "Fresh Pine Needles",
            "objectId": "prop:KR:word_3"
          }
        ]
      }
    ],
    "completionReward": {
      "rewardId": "reward:KR:ch1_keepsake",
      "keepsakeNameEn": "Giwa Hanok Courtyard & Onggi Terrace Golden Keepsake",
      "keepsakeNameNative": "대한민국 · 전주 한옥마을",
      "miraTokensBonus": 50,
      "stampChapter": 1
    }
  },
  {
    "questId": "LB:ch1:harbor:main",
    "country": "LB",
    "chapter": 1,
    "titleEn": "Summer at Teta's",
    "titleNative": "لبنان · جبيل",
    "synopsis": "Welcome, habibi! Come into the courtyard—the saj is warming up for fresh manoushe.",
    "mentorId": "npc:LB:teta_nahla",
    "mentorName": "Teta Nahla",
    "landmarkId": "landmark:LB:main",
    "objectives": [
      {
        "objectiveId": "LB:ch1:harbor:gather",
        "challengeType": "gather",
        "title": "Pantry & Terrace Harvest",
        "description": "Gather wild za'atar, mountain olive oil, and wheat flour for Teta Nahla's morning bake.",
        "targetNpcId": "npc:LB:teta_nahla",
        "targetStationId": "station:LB:gather",
        "requiredItems": [
          {
            "itemId": "item:LB:flour",
            "quantity": 1,
            "labelEn": "Wheat Flour",
            "labelNative": "Wheat Flour"
          },
          {
            "itemId": "item:LB:zaatar",
            "quantity": 1,
            "labelEn": "Wild Za'atar Blend",
            "labelNative": "Wild Za'atar Blend"
          },
          {
            "itemId": "item:LB:olive_oil",
            "quantity": 1,
            "labelEn": "Mountain Olive Oil",
            "labelNative": "Mountain Olive Oil"
          }
        ],
        "rewardItems": [
          {
            "itemId": "item:LB:gather_token",
            "quantity": 1,
            "labelEn": "Lebanon GATHER Keepsake"
          }
        ],
        "miraTokenReward": 20,
        "culturalFact": "Welcome, habibi! Come into the courtyard—the saj is warming up for fresh manoushe.",
        "vocabWords": [
          {
            "word": "Wheat Flour",
            "translit": "flour",
            "en": "Wheat Flour",
            "objectId": "prop:LB:word_1"
          },
          {
            "word": "Wild Za'atar Blend",
            "translit": "zaatar",
            "en": "Wild Za'atar Blend",
            "objectId": "prop:LB:word_2"
          },
          {
            "word": "Mountain Olive Oil",
            "translit": "olive oil",
            "en": "Mountain Olive Oil",
            "objectId": "prop:LB:word_3"
          }
        ]
      },
      {
        "objectiveId": "LB:ch1:harbor:trade",
        "challengeType": "trade",
        "title": "Share with the Souk Spice Merchant",
        "description": "Share a warm manoushe at the Byblos market in exchange for a jar of tangy crimson sumac.",
        "targetNpcId": "npc:LB:teta_nahla",
        "targetStationId": "station:LB:trade",
        "requiredItems": [
          {
            "itemId": "item:LB:flour",
            "quantity": 1,
            "labelEn": "Wheat Flour",
            "labelNative": "Wheat Flour"
          },
          {
            "itemId": "item:LB:zaatar",
            "quantity": 1,
            "labelEn": "Wild Za'atar Blend",
            "labelNative": "Wild Za'atar Blend"
          },
          {
            "itemId": "item:LB:olive_oil",
            "quantity": 1,
            "labelEn": "Mountain Olive Oil",
            "labelNative": "Mountain Olive Oil"
          }
        ],
        "rewardItems": [
          {
            "itemId": "item:LB:trade_token",
            "quantity": 1,
            "labelEn": "Lebanon TRADE Keepsake"
          }
        ],
        "miraTokenReward": 20,
        "culturalFact": "Welcome, habibi! Come into the courtyard—the saj is warming up for fresh manoushe.",
        "vocabWords": [
          {
            "word": "Wheat Flour",
            "translit": "flour",
            "en": "Wheat Flour",
            "objectId": "prop:LB:word_1"
          },
          {
            "word": "Wild Za'atar Blend",
            "translit": "zaatar",
            "en": "Wild Za'atar Blend",
            "objectId": "prop:LB:word_2"
          },
          {
            "word": "Mountain Olive Oil",
            "translit": "olive oil",
            "en": "Mountain Olive Oil",
            "objectId": "prop:LB:word_3"
          }
        ]
      },
      {
        "objectiveId": "LB:ch1:harbor:build",
        "challengeType": "build",
        "title": "Restore the Mountain Stone House",
        "description": "Arrange the red terracotta roof tiles, cedar beams, and pale limestone blocks to repair the courtyard archway.",
        "targetNpcId": "npc:LB:teta_nahla",
        "targetStationId": "station:LB:build",
        "requiredItems": [
          {
            "itemId": "item:LB:flour",
            "quantity": 1,
            "labelEn": "Wheat Flour",
            "labelNative": "Wheat Flour"
          },
          {
            "itemId": "item:LB:zaatar",
            "quantity": 1,
            "labelEn": "Wild Za'atar Blend",
            "labelNative": "Wild Za'atar Blend"
          },
          {
            "itemId": "item:LB:olive_oil",
            "quantity": 1,
            "labelEn": "Mountain Olive Oil",
            "labelNative": "Mountain Olive Oil"
          }
        ],
        "rewardItems": [
          {
            "itemId": "item:LB:build_token",
            "quantity": 1,
            "labelEn": "Lebanon BUILD Keepsake"
          }
        ],
        "miraTokenReward": 20,
        "culturalFact": "Welcome, habibi! Come into the courtyard—the saj is warming up for fresh manoushe.",
        "vocabWords": [
          {
            "word": "Wheat Flour",
            "translit": "flour",
            "en": "Wheat Flour",
            "objectId": "prop:LB:word_1"
          },
          {
            "word": "Wild Za'atar Blend",
            "translit": "zaatar",
            "en": "Wild Za'atar Blend",
            "objectId": "prop:LB:word_2"
          },
          {
            "word": "Mountain Olive Oil",
            "translit": "olive oil",
            "en": "Mountain Olive Oil",
            "objectId": "prop:LB:word_3"
          }
        ]
      },
      {
        "objectiveId": "LB:ch1:harbor:cook",
        "challengeType": "cook",
        "title": "Bake Saj Manoushe",
        "description": "Help Teta Nahla shape the dough, brush on olive oil and za'atar, and bake a warm manoushe on the saj.",
        "targetNpcId": "npc:LB:teta_nahla",
        "targetStationId": "station:LB:cook",
        "requiredItems": [
          {
            "itemId": "item:LB:flour",
            "quantity": 1,
            "labelEn": "Wheat Flour",
            "labelNative": "Wheat Flour"
          },
          {
            "itemId": "item:LB:zaatar",
            "quantity": 1,
            "labelEn": "Wild Za'atar Blend",
            "labelNative": "Wild Za'atar Blend"
          },
          {
            "itemId": "item:LB:olive_oil",
            "quantity": 1,
            "labelEn": "Mountain Olive Oil",
            "labelNative": "Mountain Olive Oil"
          }
        ],
        "rewardItems": [
          {
            "itemId": "item:LB:cook_token",
            "quantity": 1,
            "labelEn": "Lebanon COOK Keepsake"
          }
        ],
        "miraTokenReward": 20,
        "culturalFact": "Welcome, habibi! Come into the courtyard—the saj is warming up for fresh manoushe.",
        "vocabWords": [
          {
            "word": "Wheat Flour",
            "translit": "flour",
            "en": "Wheat Flour",
            "objectId": "prop:LB:word_1"
          },
          {
            "word": "Wild Za'atar Blend",
            "translit": "zaatar",
            "en": "Wild Za'atar Blend",
            "objectId": "prop:LB:word_2"
          },
          {
            "word": "Mountain Olive Oil",
            "translit": "olive oil",
            "en": "Mountain Olive Oil",
            "objectId": "prop:LB:word_3"
          }
        ]
      },
      {
        "objectiveId": "LB:ch1:harbor:word",
        "challengeType": "word",
        "title": "Words from Teta's Kitchen",
        "description": "Practice three Lebanese Arabic words with Teta Nahla before breakfast is served.",
        "targetNpcId": "npc:LB:teta_nahla",
        "targetStationId": "station:LB:word",
        "requiredItems": [
          {
            "itemId": "item:LB:flour",
            "quantity": 1,
            "labelEn": "Wheat Flour",
            "labelNative": "Wheat Flour"
          },
          {
            "itemId": "item:LB:zaatar",
            "quantity": 1,
            "labelEn": "Wild Za'atar Blend",
            "labelNative": "Wild Za'atar Blend"
          },
          {
            "itemId": "item:LB:olive_oil",
            "quantity": 1,
            "labelEn": "Mountain Olive Oil",
            "labelNative": "Mountain Olive Oil"
          }
        ],
        "rewardItems": [
          {
            "itemId": "item:LB:word_token",
            "quantity": 1,
            "labelEn": "Lebanon WORD Keepsake"
          }
        ],
        "miraTokenReward": 20,
        "culturalFact": "Welcome, habibi! Come into the courtyard—the saj is warming up for fresh manoushe.",
        "vocabWords": [
          {
            "word": "Wheat Flour",
            "translit": "flour",
            "en": "Wheat Flour",
            "objectId": "prop:LB:word_1"
          },
          {
            "word": "Wild Za'atar Blend",
            "translit": "zaatar",
            "en": "Wild Za'atar Blend",
            "objectId": "prop:LB:word_2"
          },
          {
            "word": "Mountain Olive Oil",
            "translit": "olive oil",
            "en": "Mountain Olive Oil",
            "objectId": "prop:LB:word_3"
          }
        ]
      }
    ],
    "completionReward": {
      "rewardId": "reward:LB:ch1_keepsake",
      "keepsakeNameEn": "Byblos Saj Bakery & Harbor Arch Golden Keepsake",
      "keepsakeNameNative": "لبنان · جبيل",
      "miraTokensBonus": 50,
      "stampChapter": 1
    }
  }
] as const;
